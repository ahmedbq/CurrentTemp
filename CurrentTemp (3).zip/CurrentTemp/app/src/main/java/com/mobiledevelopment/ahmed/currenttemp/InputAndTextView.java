package com.mobiledevelopment.ahmed.currenttemp;

import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import static android.R.attr.layout_alignParentTop;
import static android.R.attr.layout_gravity;
import static android.R.attr.layout_margin;
import static android.R.attr.layout_marginTop;
import static android.R.attr.width;

/**
 * Created by ahmed on 10/14/2017.
 */

public class InputAndTextView extends RelativeLayout {

    public static EditText enter_title;
    public static Button search;
    public static TextView results;

    public InputAndTextView (Context context, OnClickListener listener)
    {
        super (context);

        /*enter_text EditText*/
        enter_title = new EditText(context);
        LayoutParams enter_TitleLP = new LayoutParams(
                LayoutParams.MATCH_PARENT,
                LayoutParams.WRAP_CONTENT
        );

        enter_TitleLP.setMargins(60,60,60,60);
        enter_TitleLP.addRule(RelativeLayout.ALIGN_PARENT_TOP);

        enter_title.setLayoutParams(enter_TitleLP);
//        enter_title.setWidth(500);
        enter_title.setGravity(Gravity.CENTER);


        enter_title.setId(generateViewId());
        enter_title.setHint("enter zipcode");
        enter_title.setHintTextColor(Color.WHITE);
        enter_title.setBackgroundColor(Color.rgb(138,43,226));
        enter_title.setTextColor(Color.WHITE);
        enter_title.setMaxHeight(150);

        addView(enter_title);


        /*search Button*/
        search = new Button(context);
        LayoutParams buttonLP = new LayoutParams(
                LayoutParams.MATCH_PARENT,
                LayoutParams.WRAP_CONTENT
        );

        buttonLP.setMargins(300,0,300,0);
        buttonLP.addRule(RelativeLayout.BELOW, enter_title.getId());

        search.setId(generateViewId());
        search.setLayoutParams(buttonLP);
        search.setGravity(Gravity.CENTER);

        search.setBackgroundColor(Color.GREEN);
        search.setTextColor(Color.WHITE);
        search.setText("search");

        search.setOnClickListener(listener);

        addView(search);

        /*results TextView*/
        results = new TextView(context);
        LayoutParams resultsLP = new LayoutParams(
                LayoutParams.MATCH_PARENT,
                LayoutParams.MATCH_PARENT
        );

        resultsLP.setMargins(60, 60, 60, 60);
        resultsLP.addRule(RelativeLayout.BELOW, search.getId());

        results.setLayoutParams(resultsLP);
        results.setGravity(Gravity.CENTER);

        results.setBackgroundColor(Color.rgb(138,43,226));
        results.setTextColor(Color.WHITE);
        results.setText("results");

        addView(results);


    }

}

package com.mobiledevelopment.ahmed.currenttemp;

import android.graphics.Point;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;


public class MainActivity extends AppCompatActivity {
    private InputAndTextView WholeView;
    private String descriptionString = "test";
    private String tempString = "test";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
//        Point size = new Point();
        ButtonHandler bh = new ButtonHandler();
//        getWindowManager().getDefaultDisplay().getSize( size );
//        int w = size.x;
        WholeView = new InputAndTextView(this, bh);

        //descriptionString="";
        //tempString="";

        setContentView(WholeView);
    }


    public class FindWeatherTask extends AsyncTask<String, Void, String>
    {
        @Override
        protected String doInBackground(String... url) {
            //android.os.Debug.waitForDebugger();
            String toReturn = "DID NOT WORK";
            try {
                toReturn = getResponseFromHttpUrl(url[0]);
            }
            catch (Exception e)
            {
                Log.d("ErrorInApp","exception on get Response from HTTP Call" + e.getMessage());
                return toReturn;
            }

            return toReturn;
        }

        @Override
        protected void onPostExecute(String Data) {
            try {
                JSONObject theJSON = new JSONObject(Data);
                JSONArray weather = theJSON.getJSONArray("weather");


                descriptionString = weather.getJSONObject(0).get("description").toString();

                JSONObject main = theJSON.getJSONObject("main");

                tempString = main.get("temp").toString();

                WholeView.results.setText("Description: " + descriptionString + "\nTemperature: " + tempString + " degrees");



            }
            catch (JSONException e)
            {
                e.printStackTrace();
            }
        }
    }

    private class ButtonHandler implements View.OnClickListener
    {
        public void onClick (View v)
        {
            Uri BuiltUri = Uri.parse("http://api.openweathermap.org/data/2.5/weather").buildUpon()
                .appendQueryParameter("appid","1bf836128b99c7f5fc47cbf1cc46e073")
                .appendQueryParameter("zip", WholeView.enter_title.getText().toString())
                .appendQueryParameter("units","Imperial")
                .build();

            new FindWeatherTask().execute(BuiltUri.toString());
        }
    }

    public static String getResponseFromHttpUrl(String url) throws IOException {
        URL theURL= new URL(url);
        HttpURLConnection urlConnection = (HttpURLConnection) theURL.openConnection();
        try {
            InputStream in = urlConnection.getInputStream();

            Scanner scanner = new Scanner(in);
            scanner.useDelimiter("\\A");

            boolean hasInput = scanner.hasNext();
            if (hasInput) {
                return scanner.next();
            } else {
                return null;
            }
        } finally {
            urlConnection.disconnect();
        }
    }
}

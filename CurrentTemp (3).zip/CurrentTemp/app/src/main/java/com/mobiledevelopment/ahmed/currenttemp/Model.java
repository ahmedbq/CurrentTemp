package com.mobiledevelopment.ahmed.currenttemp;

public class Model {

    private String zipcode;
    private String description;
    private String temperature;

    public Model (String temp)
    {

    }
}
